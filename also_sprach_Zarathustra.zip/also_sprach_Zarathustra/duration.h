/*************************************************
 * Public Constants - Note duration
 *************************************************/
 
#define BR 2048   // Breve,       8/4
#define SB 1024   // Semibreve,   4/4
#define MI 512    // Minima,      2/4
#define SM 256    // Semiminima,  1/4
#define CR 128    // Croma,       1/8
#define SC 64     // Semicorma,   1/16
#define BC 32     // Biscroma,    1/32
#define SBC 16    // Semibiscroma,1/64
#define F 8       // Fusa,        1/128
